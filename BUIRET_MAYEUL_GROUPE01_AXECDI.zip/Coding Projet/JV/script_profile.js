let form = document.querySelector("form")


form.addEventListener("submit", function(event){
    event.preventDefault();

    let errorContainer = document.querySelector('.message-error')
    let errorList= document.querySelector('.message-error ul')
    errorList.innerHTML=""
    errorContainer.classList.remove('visible')
    let pseudo = document.querySelector("#pseudo")
    let email = document.querySelector('#email')
    let password=document.querySelector("#password")
    let passCheck= new RegExp(
        "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[-+_!@#$%^&*.,?])"
    );
    let passwordInitial = document.querySelector("#password")
    let password2 = document.querySelector("#password2")
    let successContainer = document.querySelector('.message-success')
    successContainer.classList.remove('visible')




    if(pseudo.value.length<6){
        errorContainer.classList.add("visible")
        pseudo.classList.add('defeat')
        pseudo.classList.remove('success')

        let err = document.createElement('li')
        err.innerText = "Le pseudo doit contenir au moins 6 caractères"
        errorList.appendChild(err)
    }else{
        pseudo.classList.remove('defeat')
        pseudo.classList.add('success')
    }


    

    if (email.value == '') {
        errorContainer.classList.add('visible')
        email.classList.add('defeat')
        email.classList.remove("success")

        let err = document.createElement("li")
        err.innerText = "Le champ email ne peut pas etre vide"
        errorList.appendChild(err)
    }else{
        email.classList.remove('defeat')
        email.classList.add('success')
    }



    
    
    if(password.value.length<10 || passCheck.test(password.value) == false) {
        errorContainer.classList.add("visible")
        password.classList.add('defeat')
        password.classList.remove('success')

        let err = document.createElement('li')
        err.innerText = "Le mot de passe doit faire 10 caractère minimum, contenir minuscule, majuscule, chiffre, caractère spécial"
        errorList.appendChild(err)
    }else{
        errorContainer.classList.remove('visible')
        password.classList.remove('defeat')
        password.classList.add("success")
    }



    if (passwordInitial.value != passwordRepeat.value){
        errorContainer.classList.add("visible")
        password2.classList.add('defeat')
        password2.classList.remove('success')

        let err = document.createElement('li')
        err.innerText = "Les mots de passes sont differents"
        errorList.appendChild(err)
    }else{
        password2.classList.remove('defeat')
        password2.classList.add('success')
    }



    if(
        pseudo.classList.contains("success")&&
        email.classList.contains("success")&&
        password.classList.contains("success")&&
        password2.classList.contains("success")
    ){
        successContainer.classList.add('visible')
    }
})

const magicButton = document.querySelector(".nav-toggler")
const navigation = document.querySelector("nav")

magicButton.addEventListener("click", toggleNav)

function toggleNav(){
  magicButton.classList.toggle("active")
  navigation.classList.toggle("active")
}
