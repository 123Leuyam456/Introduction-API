let selectedCard = null;

function selectCard(cardNumber) {
    const card = document.getElementById(`card${cardNumber}`);
    if (card.classList.contains('selected')) {
        card.classList.remove('selected');
        document.getElementById('exchangeButton').disabled = true;
    } else {
        card.classList.add('selected');
        selectedCard = cardNumber;
        checkSelectedCards();
    }
}

function checkSelectedCards() {
    if (document.querySelectorAll('.card.selected').length === 2) {
        document.getElementById('exchangeButton').removeAttribute('disabled');
    } else {
        document.getElementById('exchangeButton').disabled = true;
    }
}

function exchangeCards() {
    const card1 = document.getElementById('cardImage_01');
    const card2 = document.getElementById('cardImage_02');

    const tempSrc = card1.src;
    card1.src = card2.src;
    card2.src = tempSrc;

    document.querySelectorAll('.card.selected').forEach(card => {
        card.classList.remove('selected');
    });
    selectedCard = null;
    document.getElementById('exchangeButton').disabled = true;
}

function showImage_01(imageId) {
    const imageSrc = getImageSrc(imageId);
    const cardImage = document.getElementById('cardImage_01');
    cardImage.src = imageSrc;
}

function showImage_02(imageId) {
    const imageSrc = getImageSrc(imageId);
    const cardImage = document.getElementById('cardImage_02');
    cardImage.src = imageSrc;
}

function getImageSrc(imageId) {
    switch (imageId) {
        case 'image1':
            return 'img/dumbledore.png';
        case 'image2':
            return 'img/hagrid.png';
        case 'image3':
            return 'img/voldemort.png';
        case 'image4':
            return 'img/Harry_Potter_Card.png';
        case 'image5':
            return 'img/ron weasley.png';
        case 'image6':
            return 'img/Hermione granger.png';
        default:
            return '';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const selectPers = document.getElementById('selectPers');
    const persDisplay = document.getElementById('persDisplay');
  
    selectPers.addEventListener('change', function() {
      persDisplay.textContent = selectPers.value;
    });
});

const magicButton = document.querySelector(".nav-toggler")
const navigation = document.querySelector("nav")

magicButton.addEventListener("click", toggleNav)

function toggleNav(){
  magicButton.classList.toggle("active")
  navigation.classList.toggle("active")
}