let accordeons = document.querySelectorAll(".accordeon")
for (let i = 0; i <accordeons.length; i++){
    accordeons[i].addEventListener("click",function (){
        console.log("Accordeon" + i);
        this.classList.toggle("open")
    })
}

const magicButton = document.querySelector(".nav-toggler")
const navigation = document.querySelector("nav")

magicButton.addEventListener("click", toggleNav)

function toggleNav(){
  magicButton.classList.toggle("active")
  navigation.classList.toggle("active")
}